<?php
/**
 * Plugin Name: OpenBroadcaster Web
 * Plugin URI: https://github.com/mcdorgle/openbroadcaster
 * Description: Full-featured web interface for OpenBroadcaster stations - now playing display, music library browser, and song request system via Relay Service.
 * Version: 2.0.0
 * Author: OpenBroadcaster
 * License: MIT
 * Text Domain: openbroadcaster-web
 * 
 * Similar to SAMPHPWeb for SAM Broadcaster - provides a complete web interface
 * for listeners to view now playing info, browse the music library, and submit song requests.
 */

if (!defined('ABSPATH')) {
    exit;
}

define('OBW_VERSION', '2.0.0');
define('OBW_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('OBW_PLUGIN_URL', plugin_dir_url(__FILE__));

/**
 * Main plugin class for OpenBroadcaster Web.
 */
class OpenBroadcaster_Web {

    private static $instance = null;

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        // Core hooks
        add_action('init', array($this, 'init'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_frontend_assets'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_assets'));
        
        // Admin
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        
        // Shortcodes
        add_shortcode('ob_now_playing', array($this, 'shortcode_now_playing'));
        add_shortcode('ob_library', array($this, 'shortcode_library'));
        add_shortcode('ob_request', array($this, 'shortcode_request'));
        add_shortcode('ob_queue', array($this, 'shortcode_queue'));
        add_shortcode('ob_full_page', array($this, 'shortcode_full_page'));
        
        // AJAX handlers (for non-logged-in users too)
        add_action('wp_ajax_obw_get_now_playing', array($this, 'ajax_get_now_playing'));
        add_action('wp_ajax_nopriv_obw_get_now_playing', array($this, 'ajax_get_now_playing'));
        
        add_action('wp_ajax_obw_get_queue', array($this, 'ajax_get_queue'));
        add_action('wp_ajax_nopriv_obw_get_queue', array($this, 'ajax_get_queue'));
        
        add_action('wp_ajax_obw_search_library', array($this, 'ajax_search_library'));
        add_action('wp_ajax_nopriv_obw_search_library', array($this, 'ajax_search_library'));
        
        add_action('wp_ajax_obw_submit_request', array($this, 'ajax_submit_request'));
        add_action('wp_ajax_nopriv_obw_submit_request', array($this, 'ajax_submit_request'));
        
        // Widget
        add_action('widgets_init', array($this, 'register_widgets'));
    }

    /**
     * Initialize plugin.
     */
    public function init() {
        load_plugin_textdomain('openbroadcaster-web', false, dirname(plugin_basename(__FILE__)) . '/languages');
    }

    /**
     * Get plugin option with default.
     */
    public function get_option($key, $default = '') {
        return get_option('obw_' . $key, $default);
    }

    /**
     * Get connection mode: 'direct' or 'relay'
     */
    public function get_connection_mode() {
        return $this->get_option('connection_mode', 'direct');
    }

    /**
     * Check if using direct mode.
     */
    public function is_direct_mode() {
        return $this->get_connection_mode() === 'direct';
    }

    /**
     * Get the Direct Server URL (for direct mode).
     */
    public function get_direct_url() {
        return rtrim($this->get_option('direct_url', 'http://localhost:8585'), '/');
    }

    /**
     * Get the Relay Service API URL (for relay mode).
     */
    public function get_relay_url() {
        return rtrim($this->get_option('relay_url', 'https://relay.example.com'), '/');
    }

    /**
     * Get the Station ID (only used in relay mode).
     */
    public function get_station_id() {
        return $this->get_option('station_id', '');
    }

    /**
     * Get the API key.
     */
    public function get_api_key() {
        return $this->get_option('api_key', '');
    }

    /**
     * Build the API URL based on connection mode.
     */
    private function build_api_url($endpoint) {
        if ($this->is_direct_mode()) {
            // Direct mode: connect straight to desktop app
            return $this->get_direct_url() . '/api/' . ltrim($endpoint, '/');
        } else {
            // Relay mode: go through relay service
            $station_id = $this->get_station_id();
            return $this->get_relay_url() . '/api/v1/stations/' . urlencode($station_id) . '/' . ltrim($endpoint, '/');
        }
    }

    /**
     * Make a request to the API (direct or relay based on mode).
     */
    public function api_request($endpoint, $method = 'GET', $body = null) {
        $url = $this->build_api_url($endpoint);
        
        $args = array(
            'method' => $method,
            'timeout' => 15,
            'headers' => array(
                'Content-Type' => 'application/json',
                'Accept' => 'application/json',
            ),
        );
        
        // Add API key if configured
        $api_key = $this->get_api_key();
        if (!empty($api_key)) {
            $args['headers']['X-Api-Key'] = $api_key;
        }
        
        if ($body !== null && in_array($method, array('POST', 'PUT', 'PATCH'))) {
            $args['body'] = wp_json_encode($body);
        }
        
        $response = wp_remote_request($url, $args);
        
        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'error' => $response->get_error_message()
            );
        }
        
        $status_code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if ($status_code >= 200 && $status_code < 300) {
            return array(
                'success' => true,
                'data' => $data
            );
        } else {
            return array(
                'success' => false,
                'error' => isset($data['message']) ? $data['message'] : 'API error: ' . $status_code,
                'code' => isset($data['error']) ? $data['error'] : null
            );
        }
    }

    /**
     * Get now playing data from API.
     */
    public function get_now_playing() {
        // Validate configuration
        if ($this->is_direct_mode()) {
            $direct_url = $this->get_direct_url();
            if (empty($direct_url)) {
                return array('success' => false, 'error' => 'Direct server URL not configured');
            }
        } else {
            $station_id = $this->get_station_id();
            if (empty($station_id)) {
                return array('success' => false, 'error' => 'Station ID not configured');
            }
        }
        
        // Check cache first
        $cache_key = 'obw_now_playing_' . md5($this->build_api_url('now-playing'));
        $cached = get_transient($cache_key);
        if ($cached !== false) {
            return array('success' => true, 'data' => $cached);
        }
        
        $result = $this->api_request('now-playing');
        
        if ($result['success']) {
            // Cache for 5 seconds
            set_transient($cache_key, $result['data'], 5);
        }
        
        return $result;
    }

    /**
     * Get queue state from API.
     */
    public function get_queue() {
        return $this->api_request('queue');
    }

    /**
     * Search the music library.
     */
    public function search_library($query, $options = array()) {
        $params = array_merge(array(
            'query' => sanitize_text_field($query),
            'page' => 1,
            'per_page' => 20
        ), $options);
        
        // For direct mode, use GET with query params
        if ($this->is_direct_mode()) {
            $query_string = http_build_query($params);
            return $this->api_request('library/search?' . $query_string);
        }
        
        // For relay mode, use POST with body
        return $this->api_request('library/search', 'POST', $params);
    }

    /**
     * Submit a song request.
     */
    public function submit_request($track_id, $requester_name, $message = '') {
        $body = array(
            'trackId' => sanitize_text_field($track_id),
            'requesterName' => sanitize_text_field($requester_name),
            'message' => sanitize_textarea_field($message)
        );
        
        return $this->api_request('requests', 'POST', $body);
    }

    // =========================================================================
    // ADMIN
    // =========================================================================

    public function add_admin_menu() {
        add_menu_page(
            __('OpenBroadcaster Web', 'openbroadcaster-web'),
            __('OB Web', 'openbroadcaster-web'),
            'manage_options',
            'openbroadcaster-web',
            array($this, 'render_settings_page'),
            'dashicons-format-audio',
            80
        );
    }

    public function register_settings() {
        // Connection mode
        register_setting('obw_settings', 'obw_connection_mode', array(
            'type' => 'string',
            'sanitize_callback' => array($this, 'sanitize_connection_mode'),
            'default' => 'direct'
        ));
        
        // Direct mode settings
        register_setting('obw_settings', 'obw_direct_url', array(
            'type' => 'string',
            'sanitize_callback' => 'esc_url_raw',
            'default' => ''
        ));
        
        // Relay mode settings
        register_setting('obw_settings', 'obw_relay_url', array(
            'type' => 'string',
            'sanitize_callback' => 'esc_url_raw',
            'default' => ''
        ));
        
        register_setting('obw_settings', 'obw_station_id', array(
            'type' => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default' => ''
        ));
        
        // Shared settings
        register_setting('obw_settings', 'obw_api_key', array(
            'type' => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default' => ''
        ));
        
        // Display settings
        register_setting('obw_settings', 'obw_station_name', array(
            'type' => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default' => ''
        ));
        
        register_setting('obw_settings', 'obw_show_artwork', array(
            'type' => 'boolean',
            'default' => true
        ));
        
        register_setting('obw_settings', 'obw_show_progress', array(
            'type' => 'boolean',
            'default' => true
        ));
        
        register_setting('obw_settings', 'obw_refresh_interval', array(
            'type' => 'integer',
            'default' => 10
        ));
        
        // Request settings
        register_setting('obw_settings', 'obw_requests_enabled', array(
            'type' => 'boolean',
            'default' => true
        ));
        
        register_setting('obw_settings', 'obw_request_require_name', array(
            'type' => 'boolean',
            'default' => true
        ));
        
        register_setting('obw_settings', 'obw_request_cooldown', array(
            'type' => 'integer',
            'default' => 300
        ));
        
        // Theme settings
        register_setting('obw_settings', 'obw_theme', array(
            'type' => 'string',
            'default' => 'dark'
        ));
        
        register_setting('obw_settings', 'obw_accent_color', array(
            'type' => 'string',
            'default' => '#5bffb0'
        ));
        
        register_setting('obw_settings', 'obw_custom_css', array(
            'type' => 'string',
            'sanitize_callback' => 'wp_strip_all_tags',
            'default' => ''
        ));
    }
    
    /**
     * Sanitize connection mode setting.
     */
    public function sanitize_connection_mode($value) {
        return in_array($value, array('direct', 'relay')) ? $value : 'direct';
    }

    public function render_settings_page() {
        if (!current_user_can('manage_options')) {
            return;
        }
        
        include OBW_PLUGIN_DIR . 'includes/admin-settings.php';
    }

    public function enqueue_admin_assets($hook) {
        if ($hook !== 'toplevel_page_openbroadcaster-web') {
            return;
        }
        
        wp_enqueue_style('obw-admin', OBW_PLUGIN_URL . 'assets/css/admin.css', array(), OBW_VERSION);
    }

    // =========================================================================
    // FRONTEND
    // =========================================================================

    public function enqueue_frontend_assets() {
        wp_enqueue_style('obw-frontend', OBW_PLUGIN_URL . 'assets/css/frontend.css', array(), OBW_VERSION);
        
        wp_enqueue_script('obw-frontend', OBW_PLUGIN_URL . 'assets/js/frontend.js', array('jquery'), OBW_VERSION, true);
        
        wp_localize_script('obw-frontend', 'obwConfig', array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('obw_nonce'),
            'stationId' => $this->get_station_id(),
            'refreshInterval' => intval($this->get_option('refresh_interval', 10)) * 1000,
            'requestsEnabled' => (bool) $this->get_option('requests_enabled', true),
            'requestCooldown' => intval($this->get_option('request_cooldown', 300)),
            'i18n' => array(
                'loading' => __('Loading...', 'openbroadcaster-web'),
                'error' => __('Error loading data', 'openbroadcaster-web'),
                'offline' => __('Station Offline', 'openbroadcaster-web'),
                'searchPlaceholder' => __('Search for songs...', 'openbroadcaster-web'),
                'noResults' => __('No results found', 'openbroadcaster-web'),
                'requestSent' => __('Request sent!', 'openbroadcaster-web'),
                'requestFailed' => __('Request failed', 'openbroadcaster-web'),
                'enterName' => __('Please enter your name', 'openbroadcaster-web'),
                'cooldownActive' => __('Please wait before requesting again', 'openbroadcaster-web'),
            )
        ));
        
        // Custom CSS
        $custom_css = $this->get_option('custom_css', '');
        if (!empty($custom_css)) {
            wp_add_inline_style('obw-frontend', $custom_css);
        }
        
        // Theme colors
        $accent_color = $this->get_option('accent_color', '#5bffb0');
        $theme = $this->get_option('theme', 'dark');
        
        $theme_css = ":root { --obw-accent: {$accent_color}; }";
        if ($theme === 'light') {
            $theme_css .= " .obw-container { --obw-bg: #ffffff; --obw-card-bg: #f5f7fa; --obw-text: #1a1a2e; --obw-text-muted: #6b7280; }";
        }
        wp_add_inline_style('obw-frontend', $theme_css);
    }

    // =========================================================================
    // SHORTCODES
    // =========================================================================

    /**
     * [ob_now_playing] - Display now playing widget
     */
    public function shortcode_now_playing($atts) {
        $atts = shortcode_atts(array(
            'show_artwork' => $this->get_option('show_artwork', true),
            'show_progress' => $this->get_option('show_progress', true),
            'show_next' => true,
            'compact' => false,
        ), $atts);
        
        ob_start();
        include OBW_PLUGIN_DIR . 'templates/now-playing.php';
        return ob_get_clean();
    }

    /**
     * [ob_library] - Display library browser
     */
    public function shortcode_library($atts) {
        $atts = shortcode_atts(array(
            'show_request_button' => true,
            'results_per_page' => 20,
        ), $atts);
        
        ob_start();
        include OBW_PLUGIN_DIR . 'templates/library.php';
        return ob_get_clean();
    }

    /**
     * [ob_request] - Display request form
     */
    public function shortcode_request($atts) {
        $atts = shortcode_atts(array(
            'show_search' => true,
            'show_message' => true,
        ), $atts);
        
        if (!$this->get_option('requests_enabled', true)) {
            return '<div class="obw-notice">' . __('Song requests are currently disabled.', 'openbroadcaster-web') . '</div>';
        }
        
        ob_start();
        include OBW_PLUGIN_DIR . 'templates/request.php';
        return ob_get_clean();
    }

    /**
     * [ob_queue] - Display current queue
     */
    public function shortcode_queue($atts) {
        $atts = shortcode_atts(array(
            'max_items' => 10,
        ), $atts);
        
        ob_start();
        include OBW_PLUGIN_DIR . 'templates/queue.php';
        return ob_get_clean();
    }

    /**
     * [ob_full_page] - Display full page with all features
     */
    public function shortcode_full_page($atts) {
        $atts = shortcode_atts(array(
            'tabs' => 'now-playing,library,request,queue',
        ), $atts);
        
        ob_start();
        include OBW_PLUGIN_DIR . 'templates/full-page.php';
        return ob_get_clean();
    }

    // =========================================================================
    // AJAX HANDLERS
    // =========================================================================

    public function ajax_get_now_playing() {
        $result = $this->get_now_playing();
        wp_send_json($result);
    }

    public function ajax_get_queue() {
        $result = $this->get_queue();
        wp_send_json($result);
    }

    public function ajax_search_library() {
        check_ajax_referer('obw_nonce', 'nonce');
        
        $query = isset($_POST['query']) ? sanitize_text_field($_POST['query']) : '';
        $offset = isset($_POST['offset']) ? intval($_POST['offset']) : 0;
        $limit = isset($_POST['limit']) ? min(intval($_POST['limit']), 100) : 50;
        
        if (empty($query)) {
            wp_send_json(array('success' => false, 'error' => 'Search query required'));
        }
        
        $result = $this->search_library($query, array(
            'offset' => $offset,
            'limit' => $limit
        ));
        
        wp_send_json($result);
    }

    public function ajax_submit_request() {
        check_ajax_referer('obw_nonce', 'nonce');
        
        if (!$this->get_option('requests_enabled', true)) {
            wp_send_json(array('success' => false, 'error' => 'Requests are disabled'));
        }
        
        $track_id = isset($_POST['trackId']) ? sanitize_text_field($_POST['trackId']) : '';
        $name = isset($_POST['name']) ? sanitize_text_field($_POST['name']) : '';
        $message = isset($_POST['message']) ? sanitize_textarea_field($_POST['message']) : '';
        
        if (empty($track_id)) {
            wp_send_json(array('success' => false, 'error' => 'Track ID required'));
        }
        
        if ($this->get_option('request_require_name', true) && empty($name)) {
            wp_send_json(array('success' => false, 'error' => 'Name required'));
        }
        
        // Check cooldown using transient
        $ip = $_SERVER['REMOTE_ADDR'];
        $cooldown_key = 'obw_request_' . md5($ip);
        $last_request = get_transient($cooldown_key);
        $cooldown = intval($this->get_option('request_cooldown', 300));
        
        if ($last_request !== false && $cooldown > 0) {
            $remaining = $cooldown - (time() - $last_request);
            if ($remaining > 0) {
                wp_send_json(array(
                    'success' => false,
                    'error' => sprintf(__('Please wait %d seconds before requesting again', 'openbroadcaster-web'), $remaining)
                ));
            }
        }
        
        $result = $this->submit_request($track_id, $name, $message);
        
        if ($result['success']) {
            // Set cooldown
            set_transient($cooldown_key, time(), $cooldown);
        }
        
        wp_send_json($result);
    }

    // =========================================================================
    // WIDGETS
    // =========================================================================

    public function register_widgets() {
        include_once OBW_PLUGIN_DIR . 'includes/class-widget-now-playing.php';
        register_widget('OBW_Widget_Now_Playing');
    }
}

// Initialize plugin
OpenBroadcaster_Web::get_instance();
