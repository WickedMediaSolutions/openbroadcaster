<?php
/**
 * Now Playing Template
 * Displays the currently playing track with artwork and progress
 */

if (!defined('ABSPATH')) {
    exit;
}

// Helper function for time formatting (define early so it's available)
if (!function_exists('obw_format_time')) {
    function obw_format_time($seconds) {
        $seconds = intval($seconds);
        $minutes = floor($seconds / 60);
        $secs = $seconds % 60;
        return sprintf('%d:%02d', $minutes, $secs);
    }
}

$plugin = OpenBroadcaster_Web::get_instance();
$now_playing = $plugin->get_now_playing();
$station_name = get_option('obw_station_name', 'OpenBroadcaster');
$show_artwork = get_option('obw_show_artwork', true);
$show_progress = get_option('obw_show_progress', true);
$theme = get_option('obw_theme', 'dark');
$accent = get_option('obw_accent_color', '#5bffb0');
?>
<div class="obw-now-playing obw-theme-<?php echo esc_attr($theme); ?>" 
     data-obw-component="now-playing"
     data-obw-auto-refresh="true"
     style="--obw-accent: <?php echo esc_attr($accent); ?>;">
    
    <div class="obw-now-playing-header">
        <span class="obw-live-badge">
            <span class="obw-live-dot"></span>
            <?php _e('LIVE', 'openbroadcaster-web'); ?>
        </span>
        <span class="obw-station-name"><?php echo esc_html($station_name); ?></span>
    </div>
    
    <div class="obw-now-playing-content">
        <?php if ($now_playing['success'] && !empty($now_playing['data'])): 
            $track = $now_playing['data'];
        ?>
            <?php if ($show_artwork): ?>
                <div class="obw-artwork-container">
                    <div class="obw-artwork">
                        <?php if (!empty($track['artwork_url'])): ?>
                            <img src="<?php echo esc_url($track['artwork_url']); ?>" 
                                 alt="<?php echo esc_attr($track['title']); ?>" 
                                 class="obw-artwork-image" />
                        <?php else: ?>
                            <div class="obw-artwork-placeholder">
                                <svg viewBox="0 0 24 24" fill="currentColor">
                                    <path d="M12 3v10.55c-.59-.34-1.27-.55-2-.55-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4V7h4V3h-6z"/>
                                </svg>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="obw-visualizer">
                        <span></span><span></span><span></span><span></span><span></span>
                    </div>
                </div>
            <?php endif; ?>
            
            <div class="obw-track-info">
                <h2 class="obw-track-title"><?php echo esc_html($track['title'] ?? 'Unknown Title'); ?></h2>
                <p class="obw-track-artist"><?php echo esc_html($track['artist'] ?? 'Unknown Artist'); ?></p>
                <?php if (!empty($track['album'])): ?>
                    <p class="obw-track-album">
                        <svg viewBox="0 0 24 24" fill="currentColor" width="16" height="16">
                            <circle cx="12" cy="12" r="10" fill="none" stroke="currentColor" stroke-width="2"/>
                            <circle cx="12" cy="12" r="3"/>
                        </svg>
                        <?php echo esc_html($track['album']); ?>
                    </p>
                <?php endif; ?>
                
                <?php if (!empty($track['requested_by'])): ?>
                    <p class="obw-track-requested">
                        <?php printf(__('Requested by %s', 'openbroadcaster-web'), '<strong>' . esc_html($track['requested_by']) . '</strong>'); ?>
                    </p>
                <?php endif; ?>
            </div>
            
            <?php if ($show_progress && isset($track['position']) && isset($track['duration']) && $track['duration'] > 0): 
                $progress = ($track['position'] / $track['duration']) * 100;
            ?>
                <div class="obw-progress-container">
                    <div class="obw-progress-bar">
                        <div class="obw-progress-fill" style="width: <?php echo esc_attr($progress); ?>%"></div>
                        <div class="obw-progress-glow" style="left: <?php echo esc_attr($progress); ?>%"></div>
                    </div>
                    <div class="obw-progress-times">
                        <span class="obw-time-current" data-seconds="<?php echo esc_attr($track['position']); ?>">
                            <?php echo esc_html(obw_format_time($track['position'])); ?>
                        </span>
                        <span class="obw-time-duration" data-seconds="<?php echo esc_attr($track['duration']); ?>">
                            <?php echo esc_html(obw_format_time($track['duration'])); ?>
                        </span>
                    </div>
                </div>
            <?php endif; ?>
            
        <?php else: ?>
            <div class="obw-offline-message">
                <svg viewBox="0 0 24 24" fill="currentColor" width="48" height="48">
                    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                </svg>
                <h3><?php _e('Station Offline', 'openbroadcaster-web'); ?></h3>
                <p><?php _e('The station is currently offline. Please check back later.', 'openbroadcaster-web'); ?></p>
            </div>
        <?php endif; ?>
    </div>
</div>
